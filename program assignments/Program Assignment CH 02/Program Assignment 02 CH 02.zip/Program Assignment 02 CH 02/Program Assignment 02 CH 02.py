#Name:			Ahmed Benyusuf
#Class and Section:	CS 120 01
#Assignment:		Program Assignment 02, Chapter 02
#Due Date:		Wednesday, September 20, 2023 by 11:59pm
#Program Description:	The program will convert tempereture from celsius to farenheit
celsius = float(input('enter the temperature in celsius:'))
FreezingPoint = 32
conversion = 1.8
farenheit = (conversion * celsius) + (FreezingPoint)
print (f'Farenheit:{farenheit:}')
